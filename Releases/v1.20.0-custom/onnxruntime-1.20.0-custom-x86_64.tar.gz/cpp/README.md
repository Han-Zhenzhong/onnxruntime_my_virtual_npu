# ONNXRuntime C++ SDK

版本: 1.20.0-custom
编译日期: Wed Nov 19 10:24:36 AM CST 2025

## 目录结构

```
cpp/
├── include/          # 头文件
│   └── onnxruntime/
├── lib/              # 库文件
│   ├── libonnxruntime.so
│   └── ...
├── examples/         # 示例代码
├── ONNXRuntimeConfig.cmake  # CMake 配置
└── onnxruntime.pc    # pkg-config 文件
```

## 使用方法

### 方式 1: 使用 CMake

在您的 CMakeLists.txt 中：

```cmake
# 设置 ONNXRuntime 路径
set(ONNXRuntime_DIR /path/to/PreRelease/cpp)
find_package(ONNXRuntime REQUIRED)

# 链接库
add_executable(your_app main.cpp)
target_link_libraries(your_app onnxruntime)
```

### 方式 2: 手动编译

```bash
g++ -std=c++17 main.cpp \
    -I/path/to/PreRelease/cpp/include \
    -L/path/to/PreRelease/cpp/lib \
    -lonnxruntime \
    -o your_app

# 运行时设置库路径
export LD_LIBRARY_PATH=/path/to/PreRelease/cpp/lib:$LD_LIBRARY_PATH
./your_app
```

### 方式 3: 使用 pkg-config

```bash
export PKG_CONFIG_PATH=/path/to/PreRelease/cpp:$PKG_CONFIG_PATH

g++ main.cpp $(pkg-config --cflags --libs onnxruntime) -o your_app
```

## 示例代码

参见 `examples/` 目录：

```bash
cd examples
mkdir build && cd build
cmake .. -DONNXRuntime_DIR=../..
make
./simple_inference
```

## 自定义算子

本版本包含自定义 my_cpu 算子，支持：
- FastGelu (domain: com.my_virtual_npu)

使用方式与标准算子相同，ONNXRuntime 会自动选择正确的实现。

## 依赖

- GCC 7+ 或 Clang 5+
- CMake 3.13+
- glibc 2.17+ (Linux)

## 支持

- GitHub: https://github.com/microsoft/onnxruntime
- 文档: https://onnxruntime.ai/docs/
