// ONNXRuntime C++ API 使用示例
#include <onnxruntime/core/session/onnxruntime_cxx_api.h>
#include <iostream>
#include <vector>

int main() {
    // 1. 创建环境
    Ort::Env env(ORT_LOGGING_LEVEL_WARNING, "test");

    // 2. 创建会话选项
    Ort::SessionOptions session_options;
    session_options.SetIntraOpNumThreads(1);

    // 3. 创建会话
    Ort::Session session(env, "model.onnx", session_options);

    // 4. 打印输入输出信息
    size_t num_input_nodes = session.GetInputCount();
    size_t num_output_nodes = session.GetOutputCount();

    std::cout << "输入节点数: " << num_input_nodes << std::endl;
    std::cout << "输出节点数: " << num_output_nodes << std::endl;

    return 0;
}
