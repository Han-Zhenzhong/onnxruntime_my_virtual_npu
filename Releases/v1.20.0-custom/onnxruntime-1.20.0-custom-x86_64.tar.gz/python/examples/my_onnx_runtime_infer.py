import onnxruntime as ort
from transformers import AutoTokenizer
import numpy as np

model_path = "./tiny-gpt2-onnx/model.onnx"
tokenizer_path = "./tiny-gpt2-onnx"

tokenizer = AutoTokenizer.from_pretrained(tokenizer_path)
session = ort.InferenceSession(model_path, providers=['CPUExecutionProvider'])

prompt = "Hello, how are you"
max_new_tokens = 20

# 编码输入
input_ids = tokenizer(prompt, return_tensors="np")["input_ids"].astype(np.int64)

# 循环生成
for _ in range(max_new_tokens):
    seq_len = input_ids.shape[1]
    
    # attention_mask 全部置 1
    attention_mask = np.ones((1, seq_len), dtype=np.int64)
    
    # position_ids 从 0 到 seq_len-1
    position_ids = np.arange(seq_len, dtype=np.int64).reshape(1, seq_len)
    
    onnx_inputs = {
        "input_ids": input_ids,
        "attention_mask": attention_mask,
        "position_ids": position_ids
    }
    
    outputs = session.run(None, onnx_inputs)
    logits = outputs[0]
    
    # 取最后一个 token
    next_token_id = np.argmax(logits[0, -1, :])
    input_ids = np.concatenate([input_ids, [[next_token_id]]], axis=1)

# 解码
generated_text = tokenizer.decode(input_ids[0])
print("Generated text:\n", generated_text)

