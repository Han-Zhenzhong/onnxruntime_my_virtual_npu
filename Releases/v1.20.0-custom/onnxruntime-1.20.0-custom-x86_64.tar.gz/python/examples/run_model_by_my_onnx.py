import onnxruntime as ort

session = ort.InferenceSession(
    "/home/zhenzhong/open-source/npu/tiny-gpt2-onnx/model.onnx",
    providers=["CPUExecutionProvider"]  # 将来换成你的 NPU EP
)

inputs = session.get_inputs()
outputs = session.get_outputs()

print("Inputs:", [i.name for i in inputs])
print("Outputs:", [o.name for o in outputs])

