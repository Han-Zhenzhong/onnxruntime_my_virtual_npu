# 创建脚本分析 Tiny-GPT2 需要的确切算子
import onnx

def analyze_model_ops(model_path):
    model = onnx.load(model_path)
    ops = set()
    for node in model.graph.node:
        ops.add((node.op_type, node.domain if node.domain else ""))
    
    print("Tiny-GPT2 required operators:")
    for op_type, domain in sorted(ops):
        print(f"  - {op_type} (domain: {domain or 'onnx'})")
    
    return ops

# 运行分析
model_ops = analyze_model_ops("model.onnx")
